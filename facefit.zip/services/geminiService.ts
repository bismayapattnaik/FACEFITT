import { GoogleGenAI, Type } from "@google/genai";

// User provided specific key
const API_KEY = 'geminiai-17ac30f2c8f4dddd86fc6f5af9ddfb64';

export const generateTryOnImage = async (
  faceImageBase64: string,
  clothImageBase64: string
): Promise<string> => {
  // Initialize with the specific key provided by the user
  const ai = new GoogleGenAI({ apiKey: API_KEY });

  const cleanFace = faceImageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");
  const cleanCloth = clothImageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  // Using Gemini 3 Pro Image Preview (Nano Banana Pro)
  const modelName = 'gemini-3-pro-image-preview';

  try {
    console.log(`Attempting generation with model: ${modelName}`);
    
    const promptText = `
    ACT AS A WORLD-CLASS VIRTUAL TAILOR AND VFX ARTIST.
    
    TASK: Create a hyper-realistic "Virtual Try-On" image.
    
    INPUTS:
    - IMAGE A (PERSON): The user's face and body.
    - IMAGE B (GARMENT): The fashion item to be worn.

    CRITICAL EXECUTION STEPS:
    1. **IDENTITY LOCK**: Reconstruct the user's face from IMAGE A with 100% precision. The eyes, skin texture, and expression MUST match exactly.
    
    2. **VIRTUAL FITTING**: 
       - "Put" the garment from IMAGE B onto the person. 
       - **FIT & PHYSICS**: The garment must conform to the body's volume (chest, shoulders). It must NOT look like a flat sticker.
       - **CONTACT**: The neckline/shoulders must sit naturally on the skin. 
       - **GRAVITY**: Show natural draping and folds where the fabric hangs.
    
    3. **LIGHTING & SHADOWS (KEY TO REALISM)**:
       - The garment must cast shadows onto the user's skin (e.g., collar shadow on neck, sleeve shadow on arm).
       - The lighting on the garment must match the lighting of the user's environment in IMAGE A.
    
    4. **INTELLIGENT OUTFIT COMPLETION**:
       - **IF IMAGE B IS A TOP**: Generate matching, stylish bottoms (jeans/trousers) and shoes to complete the full body shot.
       - **IF IMAGE B IS BOTTOMS**: Generate a matching neutral top and shoes.
       - **IF IMAGE B IS SHOES**: Generate a full outfit that highlights the shoes.
       - **IF IMAGE B IS ACCESSORY**: Integrate it naturally into a full outfit.
    
    5. **OUTPUT STYLE**: 
       - 8k Resolution, RAW Fashion Photography.
       - Focus on texture, fabric details, and realistic skin-to-cloth interaction.
       - Background: Blurred luxury retail or urban street.

    NEGATIVE PROMPT:
    - Floating cloth, sticker effect, photoshop cut-out look
    - Unnatural neck connection
    - Flat lighting, no shadows
    - Cartoon, painting, illustration, 3D render style
    - Mismatched skin tones
    - Deformed body parts
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          { text: promptText },
          { inlineData: { mimeType: 'image/png', data: cleanFace } },
          { inlineData: { mimeType: 'image/png', data: cleanCloth } }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4",
          imageSize: "2K"
        }
      }
    });

    if (response.candidates && response.candidates.length > 0) {
      const parts = response.candidates[0].content.parts;
      for (const part of parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error(`Model ${modelName} returned no image data.`);

  } catch (error: any) {
    console.warn(`Model ${modelName} failed:`, error.message);
    throw new Error(error.message || "Failed to generate realistic image. Please try again.");
  }
};

export const getStyleRecommendations = async (
  faceImageBase64: string,
  clothImageBase64: string
): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });

  const cleanCloth = clothImageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          { 
            text: `You are a fashion stylist. 
            1. Analyze this fashion item.
            2. Suggest ONE specific COMPLEMENTARY item to complete the look.
            3. Provide a shopping search query for it.
            Return JSON.`
          },
          { inlineData: { mimeType: 'image/png', data: cleanCloth } }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING },
            complementaryItem: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                searchQuery: { type: Type.STRING },
                priceRange: { type: Type.STRING }
              }
            },
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  item: { type: Type.STRING },
                  reason: { type: Type.STRING },
                  color: { type: Type.STRING },
                }
              }
            }
          }
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    console.error("Style Recommendation Error:", error);
    return null;
  }
};